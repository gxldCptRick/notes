package quintanilla.alexander.exerciselog.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import quintanilla.alexander.exerciselog.models.Exercise;
import quintanilla.alexander.exerciselog.models.repositories.ExerciseJpaRepository;

@RestController
@RequestMapping("/exercises")
public class ExerciseRestController {

	@Autowired
	private ExerciseJpaRepository exerciseJpaRepository;
	
	@RequestMapping(path="", method=RequestMethod.POST)
	public Integer createExercise(@RequestBody Exercise exercise) {
		exerciseJpaRepository.saveAndFlush(exercise);
		return exercise.getId();
	}
	
	@RequestMapping(path="", method=RequestMethod.GET)
	public List<Exercise> getAllExercises(){
		return exerciseJpaRepository.findAll();
	}

	public Exercise getById(int exerciseId) {
		return exerciseJpaRepository.findById(exerciseId)
		.orElseThrow(()->new RuntimeException("no exercise with id " + exerciseId));
	}
	
}
