package com.gxldcptrick.servlet;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gxldcptrick.model.Person;

@WebServlet("/create/person")
public class CreatePersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("ps");
		EntityManager manager = emf.createEntityManager();
		var person1 = new Person("joe", 11);
		var person2 = new Person("jill", 12);
		manager.persist(person1);
		manager.persist(person2);
	}
}
