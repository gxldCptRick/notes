package com.gxldcptrick.servlet;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gxldcptrick.model.Person;

public class SearchPersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("ps");
		EntityManager manager = emf.createEntityManager();
		var builder = manager.getCriteriaBuilder();
		var query = builder.createQuery(Person.class);
		manager.createQuery(query);
	}
}
