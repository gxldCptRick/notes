package quintanilla.alexander.exerciselog.models.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import quintanilla.alexander.exerciselog.models.Set;

public interface SetJpaRepository extends JpaRepository<Set, Integer>{
	
}
