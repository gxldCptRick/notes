package quintanilla.alexander.exerciselog.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import quintanilla.alexander.exerciselog.models.Exercise;
import quintanilla.alexander.exerciselog.models.Set;
import quintanilla.alexander.exerciselog.models.repositories.SetJpaRepository;

@RestController
@RequestMapping("/sets")
public class SetRestController {

	@Autowired
	private SetJpaRepository setJpaRepository;
	
	@Autowired
	private ExerciseRestController exerciseRestController;
	
	@RequestMapping(path="/exercise/{exerciseId}", method=RequestMethod.POST)
	public Integer createSet(@PathVariable int exerciseId, @RequestBody Set set) {
		Exercise exercise = exerciseRestController.getById(exerciseId);
		set.setExercise(exercise);
		setJpaRepository.saveAndFlush(set);
		return set.getId();
	}
	
	@RequestMapping(path="", method=RequestMethod.GET)	
	public List<Set> getAllSets(){
		return setJpaRepository.findAll();
	}
}
