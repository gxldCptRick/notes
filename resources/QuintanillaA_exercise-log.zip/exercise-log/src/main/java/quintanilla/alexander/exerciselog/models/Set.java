package quintanilla.alexander.exerciselog.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="exercise_set")
public class Set {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(nullable=false)
	private int countReps;

	@Column(nullable=false)
	private int secondsRepRests;
	
	@ManyToOne
	@JoinColumn(name="exercise_id", nullable=false)
	private Exercise exercise;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getCountReps() {
		return countReps;
	}

	public void setCountReps(int countReps) {
		this.countReps = countReps;
	}

	public int getSecondsRepRests() {
		return secondsRepRests;
	}

	public void setSecondsRepRests(int secondsRepRests) {
		this.secondsRepRests = secondsRepRests;
	}
	
	public Exercise getExercise() {
		return exercise;
	}
	
	public void setExercise(Exercise exercise) {
		this.exercise = exercise;
	}
	
}
