package com.gxldcptrick;

public class Student {
	public String name;
	public int age;
	
	public Student() {}
	
	public Student(String name, int age) {
		this.name = name;
		this.age = age;
	}
}
