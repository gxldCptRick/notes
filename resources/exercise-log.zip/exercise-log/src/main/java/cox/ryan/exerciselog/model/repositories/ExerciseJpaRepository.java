package cox.ryan.exerciselog.model.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import cox.ryan.exerciselog.model.Exercise;
import cox.ryan.exerciselog.model.Set;

public interface ExerciseJpaRepository 
	extends JpaRepository<Exercise, Integer> {

	//"select * from exercise where name like '%str%'"
	public List<Exercise> findByNameLike(String name);
	
//	public List<Exercise> findByNameLikeAndSetsContains(String name, Set set);
//	
//	@Query(
//		"SELECT e "+
//		"FROM Exercise e " +
//		"WHERE e.name LIKE :name")
//	public List<Exercise> queryByNameLike(
//			@Param("name") String name);
//	
//	
//	@Query(
//			value="SELECT * FROM exercise e WHERE e.name like '%blah%'", 
//			nativeQuery=true)
//	public List<Exercise> queryBySuperComplexNative();
	
}






