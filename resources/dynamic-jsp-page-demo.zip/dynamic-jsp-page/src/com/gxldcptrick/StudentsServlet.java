package com.gxldcptrick;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/students")
public class StudentsServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		List<Student> students = new ArrayList<>();
		students.add(new Student("joe", 12));
		students.add(new Student("jill", 10));
		req.setAttribute("students", students);
		req.getRequestDispatcher("StudentListView.jsp")
		.forward(req, res);
	}
}
