package com.gxldcptrick.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// marks the class as an entity so that it can be used with JPA stuff
@Entity
// marks the table that this class is refering too. 
@Table(name="person")
public class Person {
	// marks the primary key for the class
	@Id
	private int id;
	// marks a column so that you can add some sql validation for the values
	@Column(nullable=false)
	private int age;
	
	// the name field is for when you want to map the field to a different name in the database
	@Column(name="fullname")
	private String name;
	
	// you need a default constructor so that the framework can create an instance of you object
	public Person() {
		this("DEFAULT", -1);
	}
	public Person(String name, int age){
		setAge(age);
		setName(name);
		setId(-1);
	}
	/*
	 * 
	 * You need to create getters and setters for each of the column fields
	 * 
	 * */
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	// for debugging reasons
	@Override
	public String toString() {
		return String.format("%s (%d)", getName(), getAge());
	}
}
